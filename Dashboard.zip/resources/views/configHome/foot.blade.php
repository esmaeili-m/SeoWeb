<script src="{{asset('home/js/jquery-3.6.0.min.js')}}"></script>
<script src="{{asset('home/js/bootstrap.min.js')}}"></script>
<script src="{{asset('home/js/modernizr.custom.js')}}"></script>
<script src="{{asset('home/js/jquery.easing.js')}}"></script>
<script src="{{asset('home/js/jquery.appear.js')}}"></script>
<script src="{{asset('home/js/jquery.scrollto.js')}}"></script>
<script src="{{asset('home/js/menu.js')}}"></script>
<script src="{{asset('home/js/imagesloaded.pkgd.min.js')}}"></script>
<script src="{{asset('home/js/isotope.pkgd.min.js')}}"></script>
<script src="{{asset('home/js/owl.carousel.min.js')}}"></script>
<script src="{{asset('home/js/jquery.magnific-popup.min.js')}}"></script>
<script src="{{asset('home/js/quick-form.js')}}"></script>
<script src="{{asset('home/js/request-form.js')}}"></script>
<script src="{{asset('home/js/jquery.validate.min.js')}}"></script>
<script src="{{asset('home/js/jquery.ajaxchimp.min.js')}}"></script>
<script src="{{asset('home/js/wow.js')}}"></script>

<!-- Custom Script -->
<script src="{{asset('home/js/custom.js')}}"></script>
