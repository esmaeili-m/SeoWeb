<section style="margin-top: 100px" id="content-3" class="content-3 wide-60 content-section division">
    <div class="container">


        <!-- TOP ROW -->
        <div class="top-row pb-50">
            <div class="row d-flex align-items-center">


                <!-- TEXT BLOCK -->
                <div class="col-md-7 col-lg-6 order-last order-lg-2">
                    <div class="txt-block left-column wow fadeInRight">

                        <!-- Section ID -->
                        <span class="section-id txt-upcase">موسسه گردشگری آفتاب شرق</span>

                        <!-- Title -->
                        <h2 class="h2-xs">درباره ما</h2>

                        <!-- Text -->
                        <p class="p-lg">
                            موسسه سخن آفتاب شرق پس از کسب مجوز های لازم را از سازمان میراث فرهنگی، گردشگری و صنایع دستی و در زمینه آموزش راهنمایان ایرانگردی-جهانگردی، طبیعت گردی و مدیر فنی فعالیت خود را آغاز کرده و در تلاش جهت افزایش سطح آگاهی فعالان صنعت گردشگری و ایجاد بستر مناسب جهت پیشرفت و ایجاد اشتغال در تلاش است تا گامی در جهت ارتقا سطح علمی بردارد.
                        </p>

                        <!-- Text -->



                    </div>
                </div>	<!-- END TEXT BLOCK -->


                <!-- IMAGE BLOCK -->
                <div class="col-md-5 col-lg-6 order-first order-md-2">
                    <div class="img-block left-column wow fadeInLeft">
                        <img style="border-radius: 15px" class="img-fluid " src="{{asset('home/images/about.webp')}}" alt="content-image">
                    </div>
                </div>


            </div>
        </div>	<!-- END TOP ROW -->


        <!-- BOTTOM ROW -->


    </div>	   <!-- End container -->
</section>
