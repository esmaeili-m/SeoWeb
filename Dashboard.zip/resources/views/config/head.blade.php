<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <title>
        استارت وب وان
        |
        @yield('title')
    </title>
    <!-- Favicon-->
    <link rel="icon" href="{{asset('admin/images/favicon.ico')}}" type="image/x-icon">
    <!-- Plugins Core Css -->
    <link href="{{asset('admin/css/app.min.css')}}" rel="stylesheet">
    <link href="{{asset('admin/js/bundles/materialize-rtl/materialize-rtl.min.css')}}" rel="stylesheet">
    <!-- Custom Css -->
    <link href="{{asset('admin/css/style.css')}}" rel="stylesheet" />
    <!-- Theme style. You can choose a theme from css/themes instead of get all themes -->
    <link href="{{asset('admin/css/styles/all-themes.css')}}" rel="stylesheet" />


</head>
<style>
    .table th ,td {
        text-align: center;
    }
    .style-image{
        border-radius: 15px;
        box-shadow: 3px 3px 3px #4F4847;
    }
    .card{
        box-shadow:  1px 1px 3px #968A87;

    }

</style>
